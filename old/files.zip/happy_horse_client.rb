# frozen_string_literal: true
# =============================================================================
# happy_horse_client.rb — DashScope / HappyHorse video-synthesis client
#
# This is the file linked in the Devpost submission as proof of Alibaba
# Cloud deployment (SDD §9.1): it is the only place in the codebase that
# talks to dashscope-intl.aliyuncs.com for video generation.
#
# Submits async HappyHorse jobs (t2v / i2v), polls for completion, and
# downloads results. No blocking waits beyond a single poll tick — designed
# to be called from a Sidekiq job that re-enqueues itself until terminal.
#
# Env:
#   DASHSCOPE_API_KEY   (requerido — nunca hardcodear, a diferencia del
#                        placeholder de comic_ai.rb; usar Rails credentials
#                        o Alibaba Cloud KMS en producción)
#
# Uso básico:
#   client = HappyHorseClient.new
#
#   # Texto → video (sin frame de referencia)
#   job = client.submit_t2v(
#     prompt: "A miniature city built from cardboard comes alive at night.",
#     resolution: "720P", ratio: "16:9", duration: 5
#   )
#
#   # Imagen → video (frame de referencia, usado cuando Storyboarder generó
#   # un first_frame)
#   job = client.submit_i2v(
#     prompt: "A cat dashes through the grass.",
#     first_frame_url: "https://cdn.example.com/frame.png",
#     resolution: "720P", duration: 5
#   )
#
#   result = client.poll_until_done(job.task_id)
#   client.download(result.video_url, to: "shot_1_1.mp4")
# =============================================================================

require "net/http"
require "json"
require "uri"
require "fileutils"

module HappyHorse
  class Error < StandardError; end
  class BudgetExceeded < Error; end
  class ContentPolicyError < Error; end
  class TaskFailedError < Error; end
  class TaskTimeoutError < Error; end

  # ── Value objects ──────────────────────────────────────────────────────────

  SubmitResult = Struct.new(:task_id, :request_id, :raw, keyword_init: true)

  PollResult = Struct.new(:task_id, :status, :video_url, :error_message,
                           :submit_time, :end_time, :raw, keyword_init: true) do
    def pending?   = status == "PENDING"
    def running?   = status == "RUNNING"
    def succeeded? = status == "SUCCEEDED"
    def failed?    = status == "FAILED"
    def terminal?  = succeeded? || failed?
  end

  # ── Configuración ───────────────────────────────────────────────────────────

  Config = Struct.new(:api_key, :host, :video_model, :read_timeout, :open_timeout,
                       keyword_init: true) do
    def self.default
      new(
        api_key:      ENV.fetch("DASHSCOPE_API_KEY") { raise Error, "Falta DASHSCOPE_API_KEY" },
        host:         "dashscope-intl.aliyuncs.com",
        video_model:  "happyhorse-1.1",
        read_timeout: 60,
        open_timeout: 15
      )
    end
  end
end

# ─────────────────────────────────────────────────────────────────────────────
# CLIENTE
# ─────────────────────────────────────────────────────────────────────────────

class HappyHorseClient
  SYNTHESIS_PATH = "/api/v1/services/aigc/video-generation/video-synthesis"
  TASK_PATH      = "/api/v1/tasks/%{task_id}"

  VALID_RESOLUTIONS = %w[480P 720P 1080P].freeze
  VALID_RATIOS      = %w[16:9 9:16 1:1].freeze

  # Polling: arranca rápido, retrocede a intervalos más largos para no
  # gastar cuota de requests en tareas de video que tardan minutos.
  POLL_SCHEDULE = [5, 5, 10, 10, 15, 30].freeze # segundos; el último valor se repite
  MAX_POLL_SECONDS = 360 # 6 minutos — luego TaskTimeoutError (ver SDD §9.3)

  attr_reader :config

  def initialize(config: HappyHorse::Config.default)
    @config = config
  end

  # ── Envío: texto → video ────────────────────────────────────────────────────

  def submit_t2v(prompt:, resolution: "720P", ratio: "16:9", duration: 5)
    validate_resolution!(resolution)
    validate_ratio!(ratio)

    payload = {
      model: "#{config.video_model}-t2v",
      input: { prompt: prompt },
      parameters: { resolution: resolution, ratio: ratio, duration: duration.to_i },
    }

    submit(payload)
  end

  # ── Envío: imagen (first frame) → video ─────────────────────────────────────

  def submit_i2v(prompt:, first_frame_url:, resolution: "720P", duration: 5)
    validate_resolution!(resolution)
    raise ArgumentError, "first_frame_url requerido para i2v" if first_frame_url.to_s.empty?

    payload = {
      model: "#{config.video_model}-i2v",
      input: {
        prompt: prompt,
        media: [{ type: "first_frame", url: first_frame_url }],
      },
      parameters: { resolution: resolution, duration: duration.to_i },
    }

    submit(payload)
  end

  # ── Polling de una tarea hasta estado terminal ──────────────────────────────
  #
  # Bloqueante — pensado para uso en un worker de background (Sidekiq),
  # NO en el hilo de una request HTTP de Rails. Para uso no bloqueante,
  # usar #poll_once dentro de un job que se reencola a sí mismo.

  def poll_until_done(task_id, on_tick: nil)
    elapsed = 0
    tick    = 0

    loop do
      result = poll_once(task_id)
      on_tick&.call(result, elapsed)

      return result if result.terminal?

      raise HappyHorse::TaskTimeoutError, "task #{task_id} excedió #{MAX_POLL_SECONDS}s" if elapsed >= MAX_POLL_SECONDS

      wait = POLL_SCHEDULE[tick] || POLL_SCHEDULE.last
      sleep(wait)
      elapsed += wait
      tick += 1
    end
  end

  # Una sola consulta de estado — apto para invocarse desde un Sidekiq job
  # que se reencola con `perform_in(wait_seconds, ...)`.

  def poll_once(task_id)
    uri = URI("https://#{config.host}#{format(TASK_PATH, task_id: task_id)}")
    response = http_get(uri)
    body = JSON.parse(response.body)

    output = body.dig("output") || {}
    HappyHorse::PollResult.new(
      task_id:       task_id,
      status:        output["task_status"],
      video_url:     output.dig("video_url"),
      error_message: output["message"] || body["message"],
      submit_time:   output["submit_time"],
      end_time:      output["end_time"],
      raw:           body
    )
  end

  # ── Descarga del video resultante a disco (para luego subir a OSS) ─────────

  def download(video_url, to:)
    uri = URI(video_url)
    FileUtils.mkdir_p(File.dirname(to))

    Net::HTTP.start(uri.host, uri.port, use_ssl: uri.scheme == "https") do |http|
      request = Net::HTTP::Get.new(uri)
      http.request(request) do |response|
        raise HappyHorse::Error, "descarga falló: #{response.code}" unless response.is_a?(Net::HTTPSuccess)

        File.open(to, "wb") do |f|
          response.read_body { |chunk| f.write(chunk) }
        end
      end
    end

    to
  end

  # ── Retry helper de alto nivel (SDD §9.3) ──────────────────────────────────
  #
  # Encapsula la política de reintentos para un shot: 1 reintento en fallo
  # genérico, 1 reintento con prompt reescrito si el fallo es de política
  # de contenido, y luego needs_review.

  def submit_with_retries(prompt:, mode:, first_frame_url: nil, resolution: "720P",
                           ratio: "16:9", duration: 5, max_retries: 2, on_tick: nil)
    attempt = 0
    current_prompt = prompt

    begin
      attempt += 1
      job = case mode.to_sym
            when :t2v then submit_t2v(prompt: current_prompt, resolution: resolution, ratio: ratio, duration: duration)
            when :i2v then submit_i2v(prompt: current_prompt, first_frame_url: first_frame_url, resolution: resolution, duration: duration)
            else raise ArgumentError, "mode debe ser :t2v o :i2v"
            end

      result = poll_until_done(job.task_id, on_tick: on_tick)
      raise HappyHorse::TaskFailedError, result.error_message.to_s if result.failed?

      result
    rescue HappyHorse::TaskFailedError, HappyHorse::TaskTimeoutError => e
      if attempt <= max_retries
        current_prompt = sanitize_prompt(current_prompt) if content_policy_failure?(e)
        retry
      end
      raise
    end
  end

  private

  # Heurística simple; en producción esto delega a QwenRouter (qwen-turbo)
  # para reescribir el prompt eliminando términos problemáticos (SDD §9.3).
  def content_policy_failure?(error)
    error.message.to_s.downcase.include?("policy") || error.message.to_s.downcase.include?("sensitive")
  end

  def sanitize_prompt(prompt)
    prompt.gsub(/\b(violence|gore|weapon)\b/i, "").squeeze(" ").strip
  end

  def submit(payload)
    uri = URI("https://#{config.host}#{SYNTHESIS_PATH}")
    response = http_post(uri, payload)
    body = JSON.parse(response.body)

    unless response.is_a?(Net::HTTPSuccess)
      raise HappyHorse::Error, "DashScope error #{response.code}: #{body['message'] || response.body[0, 300]}"
    end

    HappyHorse::SubmitResult.new(
      task_id:    body.dig("output", "task_id"),
      request_id: body["request_id"],
      raw:        body
    )
  end

  def http_post(uri, payload)
    http = build_http(uri)
    request = Net::HTTP::Post.new(uri)
    request["Content-Type"]      = "application/json"
    request["Authorization"]     = "Bearer #{config.api_key}"
    request["X-DashScope-Async"] = "enable"
    request.body = JSON.generate(payload)
    http.request(request)
  end

  def http_get(uri)
    http = build_http(uri)
    request = Net::HTTP::Get.new(uri)
    request["Authorization"] = "Bearer #{config.api_key}"
    response = http.request(request)
    raise HappyHorse::Error, "DashScope error #{response.code}: #{response.body[0, 300]}" unless response.is_a?(Net::HTTPSuccess)
    response
  end

  def build_http(uri)
    http = Net::HTTP.new(uri.host, uri.port)
    http.use_ssl      = true
    http.read_timeout = config.read_timeout
    http.open_timeout = config.open_timeout
    http
  end

  def validate_resolution!(value)
    raise ArgumentError, "resolution inválida: #{value.inspect}" unless VALID_RESOLUTIONS.include?(value.to_s)
  end

  def validate_ratio!(value)
    raise ArgumentError, "ratio inválido: #{value.inspect}" unless VALID_RATIOS.include?(value.to_s)
  end
end

# ─────────────────────────────────────────────────────────────────────────────
# Ejemplo de integración con Sidekiq (referencia — no ejecuta nada aquí)
#
# class VideoSynthesisJob
#   include Sidekiq::Job
#
#   def perform(shot_id, task_id = nil)
#     shot   = Shot.find(shot_id)
#     client = HappyHorseClient.new
#
#     if task_id.nil?
#       job = shot.mode.to_sym == :i2v ?
#         client.submit_i2v(prompt: shot.visual_prompt, first_frame_url: shot.first_frame_url,
#                            resolution: shot.resolution, duration: shot.duration) :
#         client.submit_t2v(prompt: shot.visual_prompt, resolution: shot.resolution,
#                            duration: shot.duration)
#       shot.update!(dashscope_task_id: job.task_id, status: "RUNNING")
#       return self.class.perform_in(5.seconds, shot_id, job.task_id)
#     end
#
#     result = client.poll_once(task_id)
#     case
#     when result.succeeded?
#       path = client.download(result.video_url, to: Rails.root.join("tmp", "shots", "#{shot_id}.mp4"))
#       UploadShotToOssJob.perform_later(shot_id, path)
#       shot.update!(status: "SUCCEEDED")
#     when result.failed?
#       shot.increment!(:retries)
#       shot.retries <= 2 ? self.class.perform_in(2.seconds, shot_id) : shot.update!(status: "needs_review")
#     else
#       self.class.perform_in(10.seconds, shot_id, task_id)
#     end
#   end
# end
# =============================================================================

if __FILE__ == $PROGRAM_NAME
  # Smoke test manual: ruby happy_horse_client.rb "prompt de prueba"
  prompt = ARGV.join(" ")
  abort "Uso: ruby happy_horse_client.rb \"prompt\"" if prompt.strip.empty?

  client = HappyHorseClient.new
  puts "▶ Enviando t2v..."
  job = client.submit_t2v(prompt: prompt, duration: 5)
  puts "  task_id: #{job.task_id}"

  puts "▶ Polling..."
  result = client.poll_until_done(job.task_id) { |r, elapsed| puts "  [#{elapsed}s] #{r.status}" }

  if result.succeeded?
    puts "✓ Video listo: #{result.video_url}"
  else
    puts "✗ Falló: #{result.error_message}"
  end
end
